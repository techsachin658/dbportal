<?php $__env->startSection('content'); ?>
    <div class="col-md-12">

              <div class="card card-plain">
                <div class="card-header card-header-primary">
                  <h4 class="card-title mt-0">Users</h4>
                  
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-hover">
                      <thead class="">
                        <tr>
                        <th>S.No</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th class="text-right">Operations</th>
                        </tr>
                       </thead>
                      <tbody>
                        <?php $i = 1; foreach($users as $user): ?>
                          <tr>
                            <td><?=$i++;?></td>
                            <td><?=$user->email?></td>
                            <td><?php if($user->is_Admin == 1){echo "Admin";}else{echo "Basic User";}?></td>
                           
                               <td class="td-actions text-right">
                               <a href="" rel="tooltip" title="Edit" class="btn btn-primary btn-link btn-sm">
                                <i class="material-icons">edit</i>
                              </a>
                              <a  rel="tooltip" title="Remove" class="btn btn-danger btn-link btn-sm">
                                <i class="material-icons">close</i>
                              </a>
                            </td>
                            
                          </tr>
                        <?php endforeach; ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/raaj/portal/resources/views/admin/users.blade.php ENDPATH**/ ?>