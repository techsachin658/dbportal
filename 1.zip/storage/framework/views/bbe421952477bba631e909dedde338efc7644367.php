<div class="sidebar" >
    <div class="logo">
        <a href="#" class="simple-text logo-normal">
          Portal
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item active ">
          <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
              <i class="material-icons">dashboard</i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(route('add-user')); ?>" class="nav-link">
              <i class="material-icons">add_circle</i>
              <p>Add User</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo e(route('user')); ?>">
              <i class="material-icons">person</i>
              <p>User Profile</p>
            </a>
          </li>
          </ul>
      </div>
    </div><?php /**PATH /home/raaj/portal/resources/views/partials/sidebar.blade.php ENDPATH**/ ?>