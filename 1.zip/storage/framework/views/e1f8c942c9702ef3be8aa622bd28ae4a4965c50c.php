 <footer class="footer">
        <div class="container-fluid">
          <nav class="float-left">
            <ul>
              <li>
                <a href="#">
                  About Us
                </a>
              </li>
              <li>
                <a href="#">
                  Blog
                </a>
              </li>
              <li>
                <a href="#">
                  Licenses
                </a>
              </li>
            </ul>
          </nav>
          <div class="copyright float-right">
            &copy;<?=date("Y")?> Database Portal
          </div>
        </div>
      </footer><?php /**PATH /home/raaj/portal/resources/views/partials/footer.blade.php ENDPATH**/ ?>