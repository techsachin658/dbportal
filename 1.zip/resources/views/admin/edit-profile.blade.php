@extends('layout.admin')
@section('content')
<h1>Edit Profile</h1>   
@endsection